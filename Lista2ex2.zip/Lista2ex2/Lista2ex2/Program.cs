﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.Write(" Digite o 1º Valor:");
            a=int.Parse(Console.ReadLine());

            Console.Write("Digite o 2º Valor:");
            b=int.Parse(Console.ReadLine());

            if (a == b)
              {
                Console.Write("são iguais");
                Console.WriteLine("");
              }
            else
              if (a > b)
                {
                Console.Write("O 1º é o maior");
                Console.WriteLine("");
                }
                 else
                 {
                Console.Write("O 2º é o maior");
                Console.WriteLine("");
                 }





        }
    }
}
