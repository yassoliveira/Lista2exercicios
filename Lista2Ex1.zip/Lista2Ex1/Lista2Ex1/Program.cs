﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.Write("Digite o 1º valor:");
            a = int.Parse(Console.ReadLine());
            
            Console.Write("Digite o 2º valor:");
            b = int.Parse(Console.ReadLine());


            if (a > b)
            {
                Console.Write("o 1º valor é maior");
                Console.WriteLine("");
            }
            else
                Console.Write("o 2º valor é maior");
                Console.WriteLine("");



        }
    }
}
