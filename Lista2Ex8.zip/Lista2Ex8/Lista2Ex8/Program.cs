﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex8
{
    class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
           
            Console.Write("Digite o Valor 1: ");
            v1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor 2: ");
            v2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor 3: ");
            v3 = double.Parse(Console.ReadLine());

            Console.WriteLine("");
            v1 = Math.Pow(v1, 2);
            v2 = Math.Pow(v2, 2);
            v3 = Math.Pow(v3, 2);
            if ((v1 + v2) == v3)
            {
                Console.WriteLine("O resultado forma um Triângulo Retângulo");
            }
            else
            {
                if ((v3 + v2) == v1)
                {
                    Console.WriteLine("O resultado forma um Triângulo Retângulo");
                }
                else
                {
                    if ((v1 + v3) == v2)
                    {
                        Console.WriteLine("O resultado forma um Triângulo Retângulo");
                    }
                    else
                    {
                        Console.WriteLine("O resultado não forma um Triângulo Retângulo");
                    }
                }
            }
        }
    }
}
