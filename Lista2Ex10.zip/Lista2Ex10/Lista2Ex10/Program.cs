﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double media;
            double x;

            Console.WriteLine("Vamos saber o seu resultado final?");
            Console.WriteLine();
            Console.WriteLine(" Digite o valor da prova 1:");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine(" Digite o valor da prova 2:");
            n2 = double.Parse(Console.ReadLine());

            x = 2 * n2;
            media = (n1 + x) / 3;

                if (media>=5)
                {
                Console.WriteLine("APROVADO");
                }
                else
                  if ( media<5)
                  {
                Console.WriteLine("REPROVADO");
                }

        }
    }
}
